# -*- encoding: utf-8 -*-
import functools

import torch
import torch.nn as nn
import torch.optim as optim
import os
import numpy as np
import argparse
from torch.utils import data
from model import Net
from bert_blstm_crf import Bert_BiLSTM_CRF
from utils import NerDataset, pad, VOCAB, tokenizer, tag2idx, idx2tag
from configparser import ConfigParser

# 读取配置文件
cfg = ConfigParser()
cfg.read('config.ini')
MODEL_DIR = cfg.get('path', 'model_dir')
MODEL_PATH = cfg.get('path', 'model_path')

parser = argparse.ArgumentParser()
parser.add_argument("--batch_size", type=int, default=64)
parser.add_argument("--lr", type=float, default=0.001)
parser.add_argument("--n_epochs", type=int, default=50)
parser.add_argument("--finetuning", dest="finetuning", action="store_true")
parser.add_argument("--top_rnns", dest="top_rnns", action="store_true")
parser.add_argument("--modeldir", type=str, default=MODEL_DIR)
parser.add_argument("--model_path", type=str, default=MODEL_PATH)
parser.add_argument("--trainset", type=str, default="data/train.txt")
parser.add_argument("--validset", type=str, default="data/dev.txt")
hp = parser.parse_args()

use_device = 'cuda'  # "cuda" if torch.cuda.is_available() else "cpu"
# os.environ['CUDA_VISIBLE_DEVICES'] = '1'


def train(model, iterator, optimizer, criterion, device):
    model.train()
    for i, batch in enumerate(iterator):
        words, x, is_heads, tags, y, seqlens = batch

        x = x.to(device)
        y = y.to(device)
        _y = y  # for monitoring
        optimizer.zero_grad()
        logits = model.neg_log_likelihood(x, y)  # logits: (N, T, VOCAB), y: (N, T)
        # print(logits.shape) # (Batch, max_len, label_nums)
        logits = logits.view(-1, logits.shape[-1])  # (N*T, VOCAB)
        y = y.view(-1)  # (N*T,)
        # writer.add_scalar('data/loss', loss.item(), )

        loss = criterion(logits, y)

        loss.backward()

        optimizer.step()

        if i == 0:
            print("=====sanity check======")
            # print("words:", words[0])
            print("x:", x.cpu().numpy()[0][:seqlens[0]])
            # print("tokens:", tokenizer.convert_ids_to_tokens(x.cpu().numpy()[0])[:seqlens[0]])
            print("is_heads:", is_heads[0])
            print("y:", _y.cpu().numpy()[0][:seqlens[0]])
            print("tags:", tags[0])
            print("seqlen:", seqlens[0])
            print('words:', words[0])
            print("=======================")

        if i % 10 == 0:  # monitoring
            print(f"step: {i}, loss: {loss.item()}")
            # if i> 10:
            #     if loss.item() < 20.0:
            #         break


def eval(model, iterator, f, device):
    model.eval()

    Words, Is_heads, Tags, Y, Y_hat = [], [], [], [], []
    with torch.no_grad():
        for i, batch in enumerate(iterator):
            words, x, is_heads, tags, y, seqlens = batch
            x = x.to(device)
            # y = y.to(device)

            _, y_hat = model(x)  # y_hat: (N, T)

            Words.extend(words)
            Is_heads.extend(is_heads)
            Tags.extend(tags)
            Y.extend(y.numpy().tolist())
            Y_hat.extend(y_hat.cpu().numpy().tolist())

    ## gets results and save
    with open("temp", 'w', encoding='utf-8') as fout:
        for words, is_heads, tags, y_hat in zip(Words, Is_heads, Tags, Y_hat):
            y_hat = [hat for head, hat in zip(is_heads, y_hat) if head == 1]
            preds = [idx2tag[hat] for hat in y_hat]
            assert len(preds) == len(words.split()) == len(tags.split())
            for w, t, p in zip(words.split()[1:-1], tags.split()[1:-1], preds[1:-1]):
                fout.write(f"{w} {t} {p}\n")
            fout.write("\n")

    ## calc metric
    y_true = np.array(
        [tag2idx[line.split()[1]] for line in open("temp", 'r', encoding='utf-8').read().splitlines() if len(line) > 0])
    y_pred = np.array(
        [tag2idx[line.split()[2]] for line in open("temp", 'r', encoding='utf-8').read().splitlines() if len(line) > 0])

    # print(y_true)
    # print(functools.reduce(np.logical_and,(y_true==y_pred,y_true>=4,y_true<=5)).astype(np.int).sum())
    num_proposed = len(y_pred[y_pred >= 4])
    num_correct = (np.logical_and(y_true == y_pred, y_true >= 4)).astype(np.int).sum()
    num_gold = len(y_true[y_true >= 4])
    # print(y_true)
    print(f"num_proposed:{num_proposed}")
    print(f"num_correct:{num_correct}")
    print(f"num_gold:{num_gold}")
    try:
        precision = num_correct / num_proposed
    except ZeroDivisionError:
        precision = 1.0

    try:
        recall = num_correct / num_gold
    except ZeroDivisionError:
        recall = 1.0

    try:
        f1 = 2 * precision * recall / (precision + recall)
    except ZeroDivisionError:
        if precision * recall == 0:
            f1 = 1.0
        else:
            f1 = 0

    # final = f + ".P%.5f_R%.5f_F%.5f" % (precision, recall, f1)
    final = f + "_DevResult.txt"
    with open(final, 'w', encoding='utf-8') as fout:
        result = open("temp", "r", encoding='utf-8').read()
        fout.write(f"{result}\n")

        fout.write(f"precision={precision}\n")
        fout.write(f"recall={recall}\n")
        fout.write(f"f1={f1}\n")

    os.remove("temp")
    print("precision=%.5f" % precision)
    print("recall=%.5f" % recall)
    print("f1=%.5f" % f1)

    def check_my(mytruelist, mypredlist, start, end):
        print('result from ' + str(start) + ' to ' + str(end))
        num_proposed = (np.logical_and(mypredlist >= start, mypredlist <= end)).astype(np.int).sum()
        # functools.reduce(np.logical_and, (y_true == y_pred, y_true >= 4, y_true <= 5))
        # num_correct = (np.logical_and(mytruelist==mypredlist, mytruelist>=start,mytruelist<=end)).astype(np.int).sum()
        num_correct = functools.reduce(np.logical_and,
                                       (mytruelist == mypredlist, mytruelist >= start, mytruelist <= end)).astype(
            np.int).sum()
        num_gold = (np.logical_and(mytruelist >= start, mytruelist <= end)).astype(np.int).sum()
        print(f"num_proposed:{num_proposed}")
        print(f"num_correct:{num_correct}")
        print(f"num_gold:{num_gold}")
        try:
            precision = num_correct / num_proposed
        except ZeroDivisionError:
            precision = 1.0

        try:
            recall = num_correct / num_gold
        except ZeroDivisionError:
            recall = 1.0

        try:
            f1 = 2 * precision * recall / (precision + recall)
        except ZeroDivisionError:
            if precision * recall == 0:
                f1 = 1.0
            else:
                f1 = 0
        print("precision=%.5f" % precision)
        print("recall=%.5f" % recall)
        print("f1=%.5f" % f1)

    # check_my(y_true,y_pred,4,5)
    # check_my(y_true,y_pred,6,7)
    # check_my(y_true,y_pred,8,9)
    # check_my(y_true,y_pred,10,11)
    return precision, recall, f1


if __name__ == "__main__":

    # nn.DataParallel
    # 读取模型结构
    model = Bert_BiLSTM_CRF(tag2idx, device=use_device).cuda()
    # 加载模型参数
    device = torch.device(use_device)  # cuda:0
    print(device, torch.zeros([1]).to(torch.device(use_device)))
    try:
        model.load_state_dict(torch.load(hp.model_path))
        print('Initial model checkpoint Done..')
    except:
        print('Not find checkpoint model..')
    # model = nn.DataParallel(model)

    train_dataset = NerDataset(hp.trainset)
    # len_train_db = len(train_db)
    # print(len_train_db)
    # train_dataset, val_dataset = torch.utils.data.random_split(train_db,[int(len(train_db)*0.8),len_train_db-int(len(train_db)*0.8)])
    print('train data')
    eval_dataset = NerDataset(hp.validset)
    print('eval data')
    print('Load Data Done')

    train_iter = data.DataLoader(dataset=train_dataset,
                                 batch_size=hp.batch_size,
                                 shuffle=True,
                                 num_workers=4,
                                 collate_fn=pad)
    eval_iter = data.DataLoader(dataset=eval_dataset,
                                batch_size=hp.batch_size,
                                shuffle=False,
                                num_workers=4,
                                collate_fn=pad)

    optimizer = optim.Adam(model.parameters(), lr=hp.lr)
    criterion = nn.CrossEntropyLoss(ignore_index=0)

    print('Start Train...,')
    f1_0 = 0.0
    for epoch in range(1, hp.n_epochs + 1):  # 每个epoch对dev集进行测试
        train(model, train_iter, optimizer, criterion, device)

        print(f"=========eval at epoch={epoch}=========")
        if not os.path.exists(hp.modeldir): os.makedirs(hp.modeldir)
        model_file = hp.model_path   # os.path.join(hp.modeldir, str(epoch)) + ".pt"
        # print('eval pre recall f1')
        precision, recall, f1 = eval(model, eval_iter, model_file, device)
        if f1 > f1_0:
            f1_0 = f1
            if epoch > 1:
                torch.save(model.state_dict(), f"{model_file}")
                print(f"weights were saved to {model_file}")
