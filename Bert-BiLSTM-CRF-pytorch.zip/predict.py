# -*- encoding: utf-8 -*-
'''
@File    :   predict.py
@Time    :   2019/12/27 19:20:51
@Author  :   Cao Shuai
@Version :   1.0
@Contact :   caoshuai@stu.scu.edu.cn
@License :   (C)Copyright 2018-2019, MILAB_SCU
@Desc    :   BERT-BILSTM-BiLSTM_CRF FOR BER
'''
import torch
import pickle
from utils import tag2idx, idx2tag
from bert_blstm_crf import Bert_BiLSTM_CRF
from pytorch_pretrained_bert import BertTokenizer
from configparser import ConfigParser

cfg = ConfigParser()
cfg.read('config.ini')

# os.environ['CUDA_VISIBLE_DEVICES'] = '1'

MODEL_PATH = cfg.get('path', 'model_path')
BERT_PATH = cfg.get('path', 'berf_path')


class BiLSTM_CRF(object):
    def __init__(self, crf_model, bert_model, device='cpu'):
        self.device = torch.device(device)
        self.model = Bert_BiLSTM_CRF(tag2idx, device=device)
        self.model.load_state_dict(torch.load(crf_model, map_location=device))
        self.model.to(device)
        self.model.eval()
        self.tokenizer = BertTokenizer.from_pretrained(bert_model)

    def predict(self, text):
        """Using BiLSTM_CRF to predict label
        
        Arguments:
            text {str} -- [description]
        """
        tokens = ['[CLS]'] + self.tokenizer.tokenize(text) + ['[SEP]']
        xx = self.tokenizer.convert_tokens_to_ids(tokens)
        xx = torch.tensor(xx).unsqueeze(0).to(self.device)
        _, y_hat = self.model(xx)
        pred_tags = []
        for tag in y_hat.squeeze():
            pred_tags.append(idx2tag[tag.item()])
        return pred_tags, tokens

    def parse(self, tokens, pred_tags):
        """Parse the predict tags to real word
        
        Arguments:
            x {List[str]} -- the origin text
            pred_tags {List[str]} -- predicted tags

        Return:
            entities {List[str]} -- a list of entities
        """
        entities = []
        entity = None

        for idx, st in enumerate(pred_tags):
            # print(idx,st)
            if entity is None:
                if st.startswith('B'):
                    entity = {}
                    entity['start'] = idx
                    entity['type'] = st[2:]
                else:
                    continue
            else:
                if st == 'O' or st == '[SEP]':
                    entity['end'] = idx
                    name = ''.join(tokens[entity['start']: entity['end']])
                    save_entity = {'text': name, 'type': entity['type']}
                    entities.append(save_entity)
                    entity = None
                elif st.startswith('B'):
                    entity['end'] = idx
                    name = ''.join(tokens[entity['start']: entity['end']])
                    save_entity = {'text': name, 'type': entity['type']}
                    entities.append(save_entity)
                    entity = {}
                    entity['start'] = idx
                    entity['type'] = st[2:]
                else:
                    continue
        return entities

    def parse2(self, tokens, pred_tags):
        """Parse the predict tags to real word

        Arguments:
            x {List[str]} -- the origin text
            pred_tags {List[str]} -- predicted tags

        Return:
            entities {List[str]} -- a list of entities
        """
        entities = []
        entity = None
        last_label = ''
        for idx, st in enumerate(pred_tags):
            if ('[CLS]' in st) or ('[PAD]' in st):
                continue
            now_label = st[2:]
            if not last_label:
                last_label = now_label
                entity = {}
                entity['start'] = idx
                entity['type'] = st[2:]
            if now_label != last_label:
                entity['end'] = idx
                name = ''.join(tokens[entity['start']: entity['end']])
                save_entity = {'text': name, 'type': entity['type']}
                entities.append(save_entity)
                entity['start'] = idx
                entity['type'] = now_label
            last_label = now_label
        return entities

    def get_ner_result(self, text):
        pred_tags, tokens = self.predict(text)
        for tag, token in zip(pred_tags, tokens):
            print(token, tag)
        entities = self.parse2(tokens, pred_tags)
        return entities


class CRF_Predict():
    def CRF_predict(self, query, CRF_MODEL_PATH='model_output/crf.pkl'):
        with open(CRF_MODEL_PATH, "rb") as f:
            crf_model = pickle.load(f)
        test_word_lists = [list(query)]
        crf_pred = crf_model.test(test_word_lists)
        return crf_pred[0], test_word_lists[0]

    def get_ner_result(self, text):
        pred_tags, tokens = self.CRF_predict(text)
        pred_tags.append('[SEP]')
        tokens.append('[SEP]')
        for tag, token in zip(pred_tags, tokens):
            print(token, tag)
        entities = self.parse(tokens, pred_tags)
        return entities

    def parse(self, tokens, pred_tags):
        """Parse the predict tags to real word

        Arguments:
            x {List[str]} -- the origin text
            pred_tags {List[str]} -- predicted tags

        Return:
            entities {List[str]} -- a list of entities
        """
        entities = []
        entity = None
        last_label = ''
        for idx, st in enumerate(pred_tags):
            if ('[CLS]' in st) or ('[PAD]' in st):
                continue
            now_label = st[2:]
            if not last_label:
                last_label = now_label
                entity = {}
                entity['start'] = idx
                entity['type'] = st[2:]
            if now_label != last_label:
                entity['end'] = idx
                name = ''.join(tokens[entity['start']: entity['end']])
                save_entity = {'text': name, 'type': entity['type']}
                entities.append(save_entity)
                entity['start'] = idx
                entity['type'] = now_label
            last_label = now_label
        return entities


if __name__ == "__main__":
    ner_model = BiLSTM_CRF(MODEL_PATH, BERT_PATH, device='cpu')  # , 'cuda'
    print(ner_model.get_ner_result('广东省佛山市南海区桂城街道南三路1号裕兴花园a座801'))
    # crf_predict = CRF_Predict()
    # print(crf_predict.get_ner_result('广东省汕头市濠江区礐石街道茂南村'))
