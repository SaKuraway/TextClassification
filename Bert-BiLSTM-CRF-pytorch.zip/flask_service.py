#!/usr/bin/env python
# encoding: utf-8
'''
@file: flask_service.py
@time: 2021/1/14 9:31
@author: SaKuraPan_
@desc:
'''
from flask import Flask, request, jsonify
from re import compile
from time import time
from predict import BiLSTM_CRF
from configparser import ConfigParser

cfg = ConfigParser()
cfg.read('config.ini')
MODEL_PATH = cfg.get('path', 'model_path')
BERT_PATH = cfg.get('path', 'berf_path')

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
# 加载模型
print('加载模型..')
bilstm_crf = BiLSTM_CRF(MODEL_PATH, BERT_PATH, device='cpu')  # , 'cuda'
print('加载成功')

@app.route('/gddw/addr/seg', methods=['POST'])
def get_IWR():
    # if not request.data:
    #     return jsonify({'error': 'empty body', 'success':False})
    try:
        code = 1
        text = request.form['text']
    except:
        code = -1
        err_message = 'The [user_addr] information is wrong or loss! Please fill in again.'
        return jsonify({'code': code, 'message': err_message, 'result': []})
    # 是否过滤非中文字符
    CN_filter = request.form['filter'] if 'filter' in request.form.keys() else 0
    text = compile('[^\u4E00-\u9FD5]+').sub('', text) if CN_filter else text
    t0 = time()
    result = bilstm_crf.get_ner_result(text)
    print('耗时{0}秒'.format(time()-t0), result)
    result = {word['type']:word['text'].replace('##','') for word in result}
    return jsonify({'code': code, 'message': 'Successed.', 'result': result})


def runmain():
    # 启动app服务, 这里指定了地址和端口号。
    app.run(host=cfg.get('website', 'host'), port=cfg.getint('website', 'port'),
            debug=cfg.getboolean('website', 'debug'))


if __name__ == '__main__':
    runmain()
