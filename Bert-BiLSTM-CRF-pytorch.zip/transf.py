import re
vodict = {
    '零':'0',
    '幺':'1',
    '一':'1',
    '二':'2',
    '三':'3',
    '四':'4',
    '五':'5',
    '六':'6',
    '七':'7',
    '八':'8',
    '九':'9'
}
def chstonum(numtext):
    dp = re.sub(r'嗯|唉','',numtext)
    dpline = re.split(r'。|，',dp)
    tmpstr = ''
    chstr = ''
    for item in dpline:
        if item == '':
            continue
        else:
            if chstr == '':
                chstr = chstr + item
                tmpstr = item
            else:
                if '个' in item:
                    if len(item) != 3:
                        continue
                    chstr = chstr + int(vodict[item[0]])*item[2]
                    tmpstr = int(vodict[item[0]])*item[2]
                else:
                    if len(item) != len(tmpstr):
                        chstr = chstr + item
                        tmpstr = item
                    else:
                        if item == tmpstr:
                            pass
                        else:
                            chstr = chstr + item
                            tmpstr = item
    numstr = ''
    print(type(chstr))
    for charc in chstr:
        numstr = numstr+vodict[charc]




    print(numstr,len(numstr))
    return numstr
# chstonum('零三幺九，三个零。嗯。幺六三四。九三幺零三')
# chstonum('零三九，零三幺九幺。零三幺九幺')
# chstonum('零三幺九。嗯。零八零。嗯。幺四零。嗯。二二八零四七')
# chstonum('零三幺九。零三幺九。零零九九。零零九九。零零四五。零零四五。三九幺七。三九幺七')
# chstonum('零三幺七。嗯。零零零。嗯。零零零。零零零九八四六')