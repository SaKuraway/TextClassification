from flask import Flask, request, jsonify
import json

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

from crf_predict import get_crf_ners

from configparser import ConfigParser
cfg = ConfigParser()
cfg.read('config.ini')

def cj_main_word(text):
    #flagcode = -1
    flagdict = {
        '电费':1,
        '电量':1,
        '路灯':2,
        '营业':3,
        '电价':4,
        '电表':5,
        '缺相':6,
        '并户':7,
        '分户':8,
        '光伏发电':9,
        '电子发票':10
    }
    def cj_pos(word,text):
        return text.find(word)/len(text)
    maxflag = ''
    tmp = 2
    for keys in flagdict.keys():
        #print(cj_pos(keys,text))
        if tmp > cj_pos(keys,text) and cj_pos(keys,text) >= 0:
            tmp = cj_pos(keys,text)
            maxflag = keys
    if maxflag != '':
        return flagdict[maxflag]
    else:
        return -1
def check_word(text):
    chresult = {}
    flagcode = cj_main_word(text)
    #print(flagcode)
    if flagcode != -1:
        if ('电费' in text or '电量' in text) and ('多' in text or '异常' in text or '贵' in text) and flagcode == 1:
            # classification = {
            #     'firstclass':'投诉、意见、建议',
            #     'secondclass':'营销服务',
            #     'thirdclass':'抄核收服务'
            # }
            # chresult.update({'tag_class':classification})
            chresult.update({'ywzldm':'YWZLDM_10000294'})
        elif '路灯' in text and flagcode == 2:
            # classification = {
            #     'firstclass': '咨询查询',
            #     'secondclass': '路灯',
            #     'thirdclass': '反映路灯故障'
            # }
            # chresult.update({'tag_class':classification})
            chresult.update({'ywzldm':'YWZLDM_10000141'})
        # elif '营业厅地址' in text:
        elif '营业' in text and ('地址' in text or '网点' in text or '时间' in text or '联系方式' in text) and flagcode == 3:
            # classification = {
            #     'firstclass': '咨询查询',
            #     'secondclass': '服务渠道',
            #     'thirdclass': '营业网点'
            # }
            # chresult.update({'tag_class':classification})
            chresult.update({'ywzldm':'YWZLDM_10000130'})
        elif '电价' in text and flagcode == 4:
            # classification = {
            #     'firstclass': '咨询查询',
            #     'secondclass': '抄核收业务',
            #     'thirdclass': '电价'
            # }
            # chresult.update({'tag_class': classification})
            chresult.update({'ywzldm':'YWZLDM_10000120'})
        elif '电表' in text and '坏' in text and flagcode == 5:
            # classification = {
            #     'firstclass': '故障抢修',
            #     'secondclass': '计量故障',
            #     'thirdclass': '烧表'
            # }
            # chresult.update({'tag_class': classification})
            chresult.update({'ywzldm':'YWZLDM_10000066'})
        elif '缺相' in text and flagcode == 6:
            # classification = {
            #     'firstclass': '故障抢修',
            #     'secondclass': '缺相',
            #     'thirdclass': '缺相'
            # }
            # chresult.update({'tag_class': classification})
            chresult.update({'ywzldm':'YWZLDM_10000007'})
        elif '并户' in text and flagcode == 7:
            # classification = {
            #     'firstclass': '用电业务',
            #     'secondclass': '用电业务办理',
            #     'thirdclass': '并户'
            # }
            # chresult.update({'tag_class': classification})
            chresult.update({'ywzldm':'YWZLDM_10000086'})
        elif '分户' in text and flagcode == 8:
            # classification = {
            #     'firstclass': '用电业务',
            #     'secondclass': '用电业务办理',
            #     'thirdclass': '分户'
            # }
            # chresult.update({'tag_class': classification})
            chresult.update({'ywzldm':'YWZLDM_10000085'})
        elif '光伏发电' in text and flagcode == 9:
            # classification = {
            #     'firstclass': '用电业务',
            #     'secondclass': '用电业务办理',
            #     'thirdclass': '光伏发电'
            # }
            # chresult.update({'tag_class': classification})
            chresult.update({'ywzldm':'YWZLDM_10000081'})
        elif '电子发票' in text and flagcode == 10:
            # classification = {
            #     'firstclass': '用电业务',
            #     'secondclass': '抄核收办理',
            #     'thirdclass': '电子发票'
            # }
            # chresult.update({'tag_class': classification})
            chresult.update({'ywzldm':'YWZLDM_10000076'})

    if '12398' in text and '投诉' in text:
        chresult.update({'complaint_12398':True})
    else:
        chresult.update({'complaint_12398': False})
    if '先生' in text:
        chresult.update({'user_gender':'男性'})
    elif '女士' in text:
        chresult.update({'user_gender': '女性'})
    return chresult


@app.route('/IWR/predict',methods=['POST'])
def get_IWR():
    if not request.data:
        return jsonify({'error':'empty body','success':False})
    mybody = request.data.decode('utf-8')
    mjson = json.loads(mybody)
    rp = check_word(mjson['text'])
    rl = get_crf_ners(mjson['text'])
    print(rl)
    for rli in rl:
        if 'user_gender' in rp.keys() or 'ywzldm' in rp.keys():
            pass
        else:
            if rli['type'] == '用户名称':
                rp.update({'username':rli['text']})
        if rli['type'] == '用户地址':
            rp.update({'address':rli['text']})
    #print(mjson,rl)
    result = {
        "result":rp,
        "success":True
    }
    return jsonify(result)

# @app.route('/add/student/', methods=['POST'])
# def add_stu():
#     if not request.data:  # 检测是否有数据
#         return ('fail')
#     student = request.data.decode('utf-8')
#     # 获取到POST过来的数据，因为我这里传过来的数据需要转换一下编码。根据晶具体情况而定
#     student_json = json.loads(student)
#     # 把区获取到的数据转为JSON格式。
#     return jsonify(student_json)
#     # 返回JSON数据。


# if __name__ == '__main__':
#     app.run(host=cfg.get('website','host'), port=cfg.getint('website','port'),debug=cfg.getboolean('website','debug'))
    # 这里指定了地址和端口号。