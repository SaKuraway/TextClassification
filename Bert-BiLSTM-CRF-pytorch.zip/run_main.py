from flask_service import runmain

if __name__ == '__main__':
    runmain()