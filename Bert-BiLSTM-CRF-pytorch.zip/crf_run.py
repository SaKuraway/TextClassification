import json, pickle

def load_model(file_name):
    """用于加载模型"""
    with open(file_name, "rb") as f:
        model = pickle.load(f)
    # model = torch.load(file_name)
    return model

CRF_MODEL_PATH = 'model_output/crf.pkl'
crf_model = load_model(CRF_MODEL_PATH)

REMOVE_O = False  # 在评估的时候是否去除O标记


def result_to_json(string, tags):
    item = {"query": ''.join(string), "entities": []}
    entity_name = ""
    entity_start = 0
    idx = 0
    for char, tag in zip(string, tags):
        if tag[0] == 'O':
            if entity_name:
                item["entities"].append(
                    {"word": entity_name, "start": entity_start, "end": idx, "type": col2name[tags[idx - 1][2:]]})
                entity_name = ""
            else:
                entity_name = ""
        elif tag[0] == "B":
            if entity_name:
                item["entities"].append(
                    {"word": entity_name, "start": entity_start, "end": idx, "type": col2name[tags[idx - 1][2:]]})
                entity_name = char
                entity_start = idx
            else:
                entity_name = char
                entity_start = idx
        elif tag[0] == "I":
            entity_name += char
        idx += 1
    if entity_name:
        item["entities"].append(
            {"word": entity_name, "start": entity_start, "end": idx, "type": col2name[tags[-1][2:]]})
    lis = []
    for li in item['entities']:
        if li['word'] == '有限公司' and li['type'] == '生产厂家':
            continue
        lis.append(li)
    item['entities'] = lis
    return item


# @parameter_verification
def test_by_crf(**kwargs):
    query = kwargs['query']
    query = query.replace(' ', '@')
    test_word_lists = [list(query)]
    crf_pred = crf_model.test(test_word_lists)
    return result_to_json(test_word_lists[0], crf_pred[0])


if __name__ == "__main__":
    query = '广州供电局有限公司/变电设施/变电三所/220kv富山巡维中心/110kv桥兴站/公用设施' * 100
    print(test_by_crf(**{'query': query}))
