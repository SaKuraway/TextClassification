import os
from shutil import copyfile

def replacefile(dir1, pyfilename, sofile, isgoon):
    if isgoon == False:
        return
    pyfile = os.path.join(dir1, pyfilename)
    if os.path.isfile(pyfile):
        (dirpath1, filestr1) = os.path.split(sofile)
        (basename, ext) = os.path.splitext(filestr1)
        dstfile = os.path.join(dir1, filestr1)
        if basename + '.py' == pyfilename:
            copyfile(sofile, dstfile)
            os.remove(pyfile)
            isgoon = False
    else:
        dir2 = os.listdir(pyfile)
        replacefile(dir2, pyfilename, sofile)

def dirwithso(dir2, sopath, isgoon):
    if isgoon == False:
        return
    files = os.listdir(dir2)
    dirls = []
    for per in files:
        perfile = os.path.join(dir2, per)
        if os.path.isfile(perfile):
            (basename0, ext0) = os.path.splitext(per)
            if ext0 == '.c':
                os.remove(perfile)
                continue
            if ext0 != '.py':
                continue
            (dirpath1, filestr1) = os.path.split(sopath)
            (basename, ext) = os.path.splitext(filestr1)
            dstfile = os.path.join(dir2, filestr1)
            compy = basename.split('.cpython')
            if len(compy) < 2:
                continue
            if (compy[0] + '.py') == per:
                print('deal file ', perfile)
                copyfile(sopath, dstfile)
                os.remove(perfile)
                isgoon = False
                break
        else:
            dirls.append(perfile)

    for perdir in dirls:
        dirwithso(perdir, sopath, isgoon)

def dealsofile(filepath):
    isgoon = True
    dir1 = './'
    dir1 = os.path.abspath(dir1)
    dirwithso(dir1, filepath, isgoon)
    if isgoon == True:
        (dirpath1, filestr1) = os.path.split(filepath)
        dstfile = os.path.join(dir1, filestr1)
        copyfile(filepath, dstfile)

def buildext():
    builddir = './build/lib.linux-x86_64-3.7'
    for i in range(1, 9):
        if os.path.exists(builddir) == True:
            break
        builddir = './build/lib.linux-x86_64-3.' + str(i)

    builddir = os.path.abspath(builddir)
    solist = os.listdir(builddir)
    for per in solist:
        perfile = os.path.join(builddir, per)
        if os.path.isfile(perfile):
            dealsofile(perfile)




if __name__ == '__main__':
    buildext()
