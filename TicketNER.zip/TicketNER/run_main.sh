#! /bin/sh

#if [ -d "./home" ]; then
#cd ./home/nlp/speech_emotion_recognition
#fi
cd `dirname $0`
pwd

#setsid python3 ./run_main.py &
nohup python3 ./run_main.py &

bash






