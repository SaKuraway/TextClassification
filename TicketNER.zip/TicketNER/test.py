#!/usr/bin/env python
# encoding: utf-8
'''
@file: main.py
@time: 2020/9/7 17:10
@author: SaKuraPan_
@desc:
'''
import requests, pandas as pd

df = pd.read_clipboard()


def asr_keywords():
    asr_path = 'E:/Documents/Program/南网程序/OperateTicket/操作票相关数据和资料/缺陷和操作票/缺陷和操作票/操作票4000个ASR热词.txt'
    existed_words = open(asr_path, 'r', encoding='utf-8').read()
    print('\n'.join(list(set(existed_words.split('\n')))))
    exit()

    with open(asr_path, 'a+', encoding='utf-8') as f:
        for operation_task, operation_addr, operation_sequence, operation_step in df.values:
            res_json = requests.post(url='http://127.0.0.1:9527/api/power/ticket',
                                     data={'task': operation_task, 'addr': operation_addr,
                                           'sequence': operation_sequence,
                                           'step': operation_step}).json()
            # print(res_json)
            if int(res_json['code']) == 1:
                if '\n'.join(res_json['res']['device']) in existed_words:
                    continue
                print(res_json['res'])
                f.write('\n')
                f.write('\n'.join(res_json['res']['device']))
                existed_words += '\n' + '\n'.join(res_json['res']['device'])
                # else:
                #     print(res_json['tips'])
        f.close()


def test_model():
    import pickle, tensorflow as tf
    from model import Model
    from utils import get_logger, create_model
    from utils import load_config
    from data_utils import load_word2vec, input_from_line
    def filter_data(operation_task, operation_addr, operation_sequence, operation_step):
        # print(operation_task,operation_addr,operation_sequence,operation_step)
        if (operation_step.startswith('再经调度令')) or (operation_step.startswith('操作')) or ('检查' in operation_step) or (
                    '确认' in operation_step) or ('核对' in operation_step) or (
                        '在' in operation_step and ((':' in operation_step) or ('：' in operation_step))):
            return (
                0, "Error Action! It seems not a valid operation ticket.[Step:操作|检查|确认|核对|再经调度|在 :]", operation_step)
        if '站' not in operation_addr:
            return (0, "Error Address! It seems not a valid operation ticket.", operation_step)
        if ('直流' in operation_task) or ('保护' in operation_task) or ('控制' in operation_task) or (
                    '功能' in operation_task) or (
                    '主站' in operation_task) or ('压板' in operation_task) or ('保护屏' in operation_task) or (
                    '备自投' in operation_task):
            return (
                0, "Error Task! It seems not a valid operation ticket.[Task:直流|保护|控制|功能|主站|压板|保护屏|备自投]", operation_step)
        if str(operation_sequence) == '1' or str(operation_sequence) == '1.0':
            return (0, "Error Sequence! It seems not a valid operation ticket.[Sequence:1]", operation_step)
        return (1, "Success!", operation_step.strip().replace(" ", ""))

    flags = tf.app.flags
    flags.DEFINE_string("ckpt_path", "ckpt", "Path to save model")
    flags.DEFINE_string("map_file", "maps.pkl", "file for maps")
    flags.DEFINE_string("vocab_file", "vocab.json", "File for vocab")
    flags.DEFINE_string("config_file", "config_file", "File for config")
    flags.DEFINE_string("train_path", "result", "Path for results")
    flags.DEFINE_string("emb_file", "wiki_100.utf8", "Path for pre_trained embedding")
    flags.DEFINE_string("called_counts_file", "./log/called_counts.log", "File for called counts log")
    flags.DEFINE_string("service_log_file", "./log/service.log", "File for service log")
    flags.DEFINE_string("evaluate_log_file", "./log/evaluate.log", "File for evaluate log")
    FLAGS = flags.FLAGS

    config = load_config(FLAGS.config_file)
    with open(FLAGS.map_file, "rb") as f:
        char_to_id, id_to_char, tag_to_id, id_to_tag = pickle.load(f)
    # 接口相关日志存放位置
    rest_logger = get_logger(FLAGS.service_log_file)
    logger = get_logger(FLAGS.evaluate_log_file)
    # 后台读取模型加快预测速度
    tf_config = tf.ConfigProto()
    sess = tf.Session(config=tf_config)
    sess.run(tf.global_variables_initializer())
    model = create_model(sess, Model, FLAGS.ckpt_path, load_word2vec, config, id_to_char, logger)
    for operation_task, operation_addr, operation_sequence, operation_step in df.values:
        code, tips, process_step = filter_data(operation_task, operation_addr, operation_sequence, operation_step)
        if not code:
            res = model.evaluate_line(sess, input_from_line("避雷器计数器内部故障", char_to_id), id_to_tag)
            print('result:', res)


def test_api():
    for operation_task, operation_addr, operation_sequence, operation_step in df.values:
        res_json = requests.post(url='http://127.0.0.1:9527/api/power/ticket',
                                 data={'task': operation_task, 'addr': operation_addr,
                                       'sequence': operation_sequence,
                                       'step': operation_step}).json()
        # print(res_json)
        if res_json['code'] == 1:
            print(res_json['res'])
        else:
            print(res_json['tips'])


if __name__ == '__main__':
    test_api()
