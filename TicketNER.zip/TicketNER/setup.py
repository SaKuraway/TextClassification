from distutils.core import setup
from Cython.Build import cythonize

setup(ext_modules=cythonize(['conlleval.py']))
setup(ext_modules=cythonize(['data_utils.py']))
setup(ext_modules=cythonize(['DeviceSimilar.py']))
setup(ext_modules=cythonize(['filter_data.py']))
setup(ext_modules=cythonize(['json2ner.py']))
setup(ext_modules=cythonize(['loader.py']))
setup(ext_modules=cythonize(['main.py']))
setup(ext_modules=cythonize(['model.py']))
setup(ext_modules=cythonize(['rnncell.py']))
setup(ext_modules=cythonize(['ticket_service.py']))
setup(ext_modules=cythonize(['utils.py']))


