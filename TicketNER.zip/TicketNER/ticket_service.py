"""
@author: SaKuraPan_
@contact: sakura_way@qq.com
@software: PyCharm
@file: ticket_service.py
@time: 2021/4/12 11:25
"""

from flask import Flask
from flask import request
from flask import jsonify
from threading import Timer
import pickle, json, configparser
import tensorflow as tf
from model import Model
from utils import get_logger, create_model
from utils import load_config
from data_utils import load_word2vec, input_from_line
from filter_data import filter_data
from DeviceSimilar import Device_Match


# 读取配置文件
conf = configparser.ConfigParser()
conf.read("config.ini")
is_debug = conf.get("Basic", "debug")
log_path = conf.get("Basic", "log_path")
count_freq = int(conf.get("Basic", "count_freq"))
if is_debug == 'True':
    host = conf.get("Server_dev", "host")
    port = conf.get("Server_dev", "port")
else:
    host = conf.get("Server_pro", "host")
    port = conf.get("Server_pro", "port")
print(is_debug, host, port)

flags = tf.app.flags
flags.DEFINE_string("ckpt_path", "ckpt", "Path to save model")
flags.DEFINE_string("map_file", "maps.pkl", "file for maps")
flags.DEFINE_string("vocab_file", "vocab.json", "File for vocab")
flags.DEFINE_string("config_file", "config_file", "File for config")
flags.DEFINE_string("train_path", "result", "Path for results")
flags.DEFINE_string("emb_file", "wiki_100.utf8", "Path for pre_trained embedding")
flags.DEFINE_string("called_counts_file", log_path + "called_counts.log", "File for called counts log")
flags.DEFINE_string("service_log_file", log_path + "service.log", "File for service log")
flags.DEFINE_string("evaluate_log_file", log_path + "evaluate.log", "File for evaluate log")
FLAGS = flags.FLAGS

# 接口相关日志存放位置
rest_logger = get_logger(FLAGS.service_log_file)
logger = get_logger(FLAGS.evaluate_log_file)
# 读取配置文件
config = load_config(FLAGS.config_file)
with open(FLAGS.map_file, "rb") as f:
    char_to_id, id_to_char, tag_to_id, id_to_tag = pickle.load(f)
# 后台读取模型加快预测速度
tf_config = tf.ConfigProto()
sess = tf.Session(config=tf_config)
sess.run(tf.global_variables_initializer())
model = create_model(sess, Model, FLAGS.ckpt_path, load_word2vec, config, id_to_char, logger)
# 加载设备id匹配算法
device_match = Device_Match()
ignore_act = ['检查']
account_devices = ['断路器', '开关', '刀闸', '地刀', '地线']
sevice_to_act = {
    "断路器": ["断开", "合上"],
    "负荷开关": ["断开", "合上"],
    "空气开关": ["断开", "合上"],
    "隔离开关": ["拉开", "合上"],
    "接地开关": ["拉开", "合上"],
    "手车": ["拉", '推', '摇', "拉至", "推至", "摇至"],
    "COMPASS": ["拉", '推', '摇', "拉至", "推至", "摇至"],
    "熔断器": ["取下", "投上"],
    "二次端子": ["连通", "短接", "隔离"],
    "连接片": ["投入", "退出"],
    "接地线": ["装设", "拆除"],
    "绝缘挡板": ["装设", "拆除"],
    "遮栏": ["装设", "拆除"],
    "标示牌": ["悬挂", "取下"],
    "红布帘": ["悬挂", "取下"],
    "位置开关": ["切换"],
    "转换开关": ["切换"],
    "分接头": ["调整"],
    "变压器高压分接头": ["调整"],
    # Third name
    "接地刀闸": ["拉开", "合上"],
    "地刀": ["拉开", "合上"],
    "刀闸": ["拉开", "合上"],
    "压板": ["投入", "退出"],
    "小车": ["拉", '推', '摇', "拉至", "推至", "摇至"],
    "抽头": ["调整"],
    "开关": ["拉开", "合上"],
}
third_name = {
    "接地刀闸": "接地开关",
    "地刀": "接地开关",
    "刀闸": "隔离开关",
    "压板": "连接片",
    "小车": "手车",
    "抽头": "分接头",
    "开关": "断路器",
}
try:
    called_count = int(open(FLAGS.called_counts_file, 'r', encoding='utf-8').read())  # 统计服务被调用次数
except:
    called_count = 0

app = Flask(__name__)


def heartbeat(freq=count_freq):
    """
    定义心跳检测函数,写入called_count日志
    """
    with open(FLAGS.called_counts_file, 'w', encoding='utf-8') as f:
        f.write(str(called_count))
        f.close()
    timer = Timer(freq, heartbeat)
    timer.start()


def process_text(text):
    return text.operation_step.strip().replace(" ", "")


@app.route('/api/power/ticket', methods=['POST'])
def get_power_input_all():
    global wanted, called_count, enti1
    try:
        print('input json:', request.data.decode('utf-8'))
        # 从请求中获取参数信息
        input_json = json.loads(request.data)
        threshold = input_json['threshold'] if input_json in input_json else 0.65
        try:
            operation_tickets = input_json['tickets']
            bureau_code = input_json['bureauCode']
            operation_addrID = input_json['functionLocationId']
        except Exception as e:
            return jsonify({'code': -1, 'message': 'Lacking params.' + str(e), "called_count": called_count})
        # 台账数据传至本地
        if operation_addrID+'.json' in listdir('./account/'):
            open(operation_addrID+'.json', 'r', encoding='utf-8').readlines()
        with open(operation_addrID+'.json', 'w', encoding='utf-8') as f:
            data={bureau_code+operation_addrID}
            f.write(requests.post(url,headers,data).json())
            f.close()
        operation_accounts = json.loads(request.form['accounts'])
        device_dict = {account['fullPath']: account['id'] for account in operation_accounts}
        if not device_dict:
            return jsonify({'code': 0, 'message': 'Plz fill the accounts.', 'result': [], "called_count": called_count})
        # 调用api台账数据库
        # device_dict = device_api(station_id)
        operation_task = operation_tickets['operationTask']  # request.form.get('task')  # 操作任务
        operation_addr = operation_tickets['locationName']  # request.form.get('addr')  # 操作地点
        operation_sequence_list = [operation_steps['sequenceNo'] for operation_steps in
                                   operation_tickets['relationSteps']]  # request.form.get('sequence')  # 操作顺序
        operation_step_list = [operation_steps['operationStep'] for operation_steps in
                               operation_tickets['relationSteps']]  # request.form.get('step')  # 操作步骤
        wanteds = []
        for operation_sequence, operation_step in zip(operation_sequence_list, operation_step_list):
            try:
                print(operation_task, operation_addr, operation_sequence, operation_step)
                # 查询此操作票是否对模型抽取有效
                code, tips, process_step = filter_data(operation_task, operation_addr, operation_sequence,
                                                       operation_step)
                # 返回api需求结果
                resuslt = {
                    "act": "",
                    "device": "",
                    "status": "",
                }
                wanted = {
                    "code": code,
                    "tips": tips,
                    "sequence": operation_sequence,
                    "ticket": operation_step,
                    "res": resuslt
                }
                if not code:
                    wanteds.append(wanted)
                    continue
                # 非有效操作票
                # if not flag:
                #     return jsonify(wanted)
                # 调用model预测

                res = model.evaluate_line(sess, input_from_line(process_step, char_to_id), id_to_tag)
                print('result:', res)
                right_act = ignore_act
                act_list = []
                sevice_list = []
                device_list = []
                device_account = []
                status_list = []
                find_act = ""
                # 解析model抽取的实体结果
                for entity in res["entities"]:
                    # Name设备名称
                    if entity["type"] == 'N':
                        enti = entity["word"]
                        for sevice in sevice_to_act.keys():
                            if sevice in enti:
                                sevice_list.append(sevice)
                                right_act += sevice_to_act[sevice]
                        device_list.append(enti)
                        # 匹配台账设备ID
                        print(','.join(device_list), account_devices, [account_device for account_device in account_devices if account_device in ','.join(device_list)])
                        if [account_device for account_device in account_devices if account_device in ','.join(device_list)]:
                            # 包含有台账的设备才开始匹配
                            max_index, max_result, result_proba = device_match.api_return(station=operation_addr,
                                                                                          find_device=enti,
                                                                                          devices_list=list(
                                                                                              device_dict.keys()))
                            print('=' * 10, max_index, max_result, result_proba)
                            if result_proba >= float(threshold):
                                device_account.append(
                                    {'deviceName': max_result, 'deviceID': device_dict[list(device_dict.keys())[max_index]],
                                     'Proba': result_proba})
                    # ACT动作
                    if entity["type"] == 'A':
                        find_act = entity["word"]
                        act_list.append(find_act)
                    # Status状态
                    if entity["type"] == 'S':
                        status = entity["word"]
                        # resuslt["status"] = status
                        status_list.append(status)
                # 匹配动作是否正确
                for act in act_list:
                    if act not in right_act:
                        resuslt["action_verify"] = "动词不匹配！[{0}]的正确操作动作应为[{1}]".format("/".join(sevice_list),
                                                                                  "/".join(set(right_act)))
                # 动作和设备list
                resuslt["act"] = act_list
                resuslt["device"] = device_list
                resuslt["device_id"] = device_account
                # 状态(初始和最终)
                if len(status_list) >= 2:
                    resuslt["initial_status"] = status_list[0]
                    resuslt["final_status"] = status_list[-1]
                else:
                    resuslt["status"] = status_list[-1:]
                wanted["res"] = resuslt

            except Exception as e:
                rest_logger.error(e)
                wanted["code"] = 0
                wanted["tips"] = "failed!" + str(e)
            wanteds.append(wanted)

    except Exception as e:
        return jsonify(
            {'code': -1, 'message': 'Failed.', 'result': e, "called_count": called_count})
    else:
        return jsonify(
            {'code': 1, 'message': 'Successed.', 'operation_addr': operation_addr, 'operation_task': operation_task,
             'result': wanteds, "called_count": called_count})
    finally:
        called_count += 1  # api被调用计数+1
        #     with open(FLAGS.called_counts_file, 'w', encoding='utf-8') as f:
        #         f.write(str(called_count))
        #         f.close()


def runmain():
    app.config['JSON_AS_ASCII'] = False
    app.run(host=host, port=int(port))


heartbeat()

if __name__ == "__main__":
    runmain()
    # 将10kV#2电容器及542开关由热备用转检修
    # 投入110kV沐东线保护跳闸出口压板
    # 退出10kV工业园Ⅱ线F1A51A开关重合闸
    # 拉开35kV#3变中CT侧303C0接地刀闸
