import os, json

RATIO = (0.7, 0.2, 0.1)
json_url = './data/source/'
json_dir = os.listdir(json_url)
json_num = len(json_dir)
ratio_json = {'train': json_dir[0:int(RATIO[0] * json_num)],
              'dev': json_dir[int(RATIO[0] * json_num):int((RATIO[0] + RATIO[1]) * json_num)],
              'test': json_dir[int((RATIO[0] + RATIO[1]) * json_num):],
              'total': json_dir}


def json2ner(type_='total'):
    with open(json_url + '{0}.txt'.format(type_), 'w', encoding='utf-8') as f:
        for json_file in ratio_json[type_]:
            print(json_file)
            json_dict = json.load(open(json_url + json_file, 'r', encoding='utf-8'))
            print(json_dict)
            for id, text_gaps in json_dict.items():
                text = text_gaps['text']
                if not text.strip():
                    continue
                tags = text_gaps['tags']
                f.write(text + ' ' + tags + '\n')
            f.write('\n')


if __name__ == '__main__':
    json2ner('train')
    json2ner('dev')
    json2ner('test')
