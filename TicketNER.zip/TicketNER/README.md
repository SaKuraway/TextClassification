##训练
语料指定在main.py中48-50行，需要提供训练、测试、验证；建议比例---->>7：2：1
python main.py train=True clearn=True
##操作票处理主文件
python ticket_service.py 