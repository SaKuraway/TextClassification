#!/usr/bin/env python
# encoding: utf-8
'''
@file: get_data.py
@time: 2020/8/27 9:13
@author: SaKuraPan_
@desc:
'''


def filter_data(operation_task, operation_addr, operation_sequence, operation_step):
    # print(operation_task,operation_addr,operation_sequence,operation_step)
    if (operation_step.startswith('再经调度令')) or (operation_step.startswith('操作')) or ('确认' in operation_step) or ('核对' in operation_step) or ('在'in operation_step and ((':' in operation_step) or ('：' in operation_step))):#  or ('检查' in operation_step)
        return (0, "Error Action! It seems not a valid operation ticket.[Step:操作|确认|核对|再经调度|在 :]", operation_step)
    if '站' not in operation_addr:
        return (0, "Error Address! It seems not a valid operation ticket.", operation_step)
    if ('直流' in operation_task) or ('保护' in operation_task) or ('控制' in operation_task) or ('功能' in operation_task) or (
        '主站' in operation_task) or ('压板' in operation_task) or ('保护屏' in operation_task) or ('备自投' in operation_task):
        return (0, "Error Task! It seems not a valid operation ticket.[Task:直流|保护|控制|功能|主站|压板|保护屏|备自投]", operation_step)
    if str(operation_sequence) == '1' or str(operation_sequence) == '1.0':
        return (0, "Error Sequence! It seems not a valid operation ticket.[Sequence:1]", operation_step)
    return (1, "Success!", operation_step.strip().replace(" ", ""))


def filter_file(file_path, encoding='utf-8'):
    from pandas import read_csv

    data_df = read_csv(file_path, encoding)
    process_df = data_df[(-data_df['操作步骤'].str.contains('检查|确认|核对')) & (data_df['操作地点'].str.contains('站')) & (
        -data_df['操作任务'].str.contains('直流|保护|控制|功能|主站|压板|保护屏|备自投', )) & (data_df['操作顺序'] != 1.0) & (
                             data_df['操作顺序'] != 2.0)]
    process_df['操作步骤'] = process_df['操作步骤'].str.replace(' ', '')
    # 在xxx：

    process_df.to_excel('E:/Documents/Program/南网程序/OperateTicket/操作票相关数据和资料/操作票整合/主网一次有效操作票广州.xlsx')


if __name__ == '__main__':
    # filter_data('投入110kV龙梅上Ⅱ线1152开关重合闸', '220kV梅林站', '1.0', '接调度令')
    filter_file(file_path='E:/Documents/Program/南网程序/OperateTicket/操作票相关数据和资料/操作票整合/操作票广州.csv', encoding='gbk')
