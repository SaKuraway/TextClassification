## 此处存放ERNIE预训练模型：  
pytorch_model.bin  
bert_config.json  
vocab.txt  

## 下载地址：  
http://image.nghuyong.top/ERNIE.zip  