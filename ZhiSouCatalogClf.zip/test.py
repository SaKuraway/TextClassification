#!/usr/bin/env python
# encoding: utf-8
'''
@file: test.py
@time: 2021/6/18 8:51
@author: SaKuraPan_
@desc:
'''
import requests

url = 'http://0.0.0.0:27519/1000/intent'
data = {
    'text': '人资系统怎么操作',
    'model': 'LSTM'
}
print(requests.post(url=url, data=data).text)
