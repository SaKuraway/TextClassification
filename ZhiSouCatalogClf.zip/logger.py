# -*- encoding: utf-8 -*-
# @Time    : 2019/8/6 15:30
# @Author  : fengqy
# @Project: seo_project

import os
import sys
import logging
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler


def get_logger(name, log_path=None,log_file=None):
    """
    logger
    :param name: 模块名称
    :param log_file: 日志文件，如无则输出到标准输出
    :return:
    """
    logger = logging.getLogger(name)
    #  这里进行判断，如果logger.handlers列表为空，则添加，否则，直接去写日志
    if not logger.handlers:
        logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

        log_file_handler = TimedRotatingFileHandler(filename=os.path.join(log_path, log_file),
                                                    when="D", interval=1, backupCount=30,encoding='utf-8')
        log_file_handler.setFormatter(formatter)
        log_file_handler.setLevel(logging.DEBUG)
        logger.addHandler(log_file_handler)

        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)
    return logger

def loggings(*args, type='INFO'):
    """
    将printf出来的数据保存到LOG文件。
    :param args:
    :return:
    """
    args = ' '.join([str(arg) for arg in args])
    if type == 'DEBUG':
        logger.debug(args)
    elif type == 'INFO':
        logger.info(args)
    elif type == 'WARNING':
        logger.warning(args)
    elif type == 'ERROR':
        logger.error(args)
    elif type == 'CRITICAL':
        logger.critical(args)

if __name__ == '__main__':
    logger = get_logger('log..', 'Logs')
    loggings('打印日志')