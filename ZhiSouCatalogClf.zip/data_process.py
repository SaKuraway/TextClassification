#!/usr/bin/env python
# encoding: utf-8
'''
@file: data_processing.py
@time: 2021/7/7 14:18
@author: SaKuraPan_
@desc:
'''
import os
import pandas as pd, jieba
import numpy as np
from collections import OrderedDict

# 去停用词
stopwords = []
with open("./lib/stopwords.txt", "r", encoding="utf8") as f:
    for w in f:
        stopwords.append(w.strip())
# 自定义分词
jieba.load_userdict('./lib/user_dict.txt')


def process_title_article(text_type, input_path='./document/智网txt/', ouput_file='./data/train.txt',
                          content_len=254):
    def replace_str(text):
        return text.strip().replace('.docx', '').replace('.pdf', '').replace('.txt', '').replace('~$', ' ').replace(
            '	', ' ').replace('', ' ').replace(',', '，').replace('﻿', ' ').replace(' ', ' ').replace('\n',
                                                                                                         ' ').replace(
            '\t', ' ').replace('  ', ' ').replace(' ', '')

    dir_list = os.listdir(input_path)
    with open(ouput_file, 'w', encoding='utf-8') as f:
        for dir in dir_list:
            label = dir.split('、')[-1]
            file_list = os.listdir(input_path + dir)
            for file in file_list:
                try:
                    title = replace_str(file)  # 文件名
                    content = replace_str(open(input_path + dir + '/' + file, 'r', encoding='utf-8').read())
                    # 限长：前面length个词拼接后面length个词
                    limit_content = content[:content_len] + '——' + content[-content_len:] if len(
                        content) > content_len * 2 else content
                except Exception as e:
                    print(input_path + dir + '/' + file, e)
                if (len(title) < 2) or (len(limit_content) < 3):
                    continue
                # 前面length个词拼接后面length个词
                text = title if text_type == 'title' else limit_content if text_type == 'article' else title + ',' + limit_content if text_type == 'both' else None
                f.write(label + ',' + text + '\n')
                print(label, text)
        f.close()


def get_data(file_type, resource='total', data_dir='./data/', label_output='./data/ml_class.txt'):
    # 读取csv数据
    if file_type == 'title':
        train_path = data_dir + 'train_title_upsample.txt'
        dev_path = data_dir + 'dev_title.txt'
        test_path = data_dir + 'test_title.txt'
    elif file_type == 'article':
        # 文章使用机器学习模型来训练
        if resource == 'total':
            # Total_class
            train_path = data_dir + 'train_total_article_upsample.txt'
            dev_path = data_dir + 'dev_total_article.txt'
            test_path = data_dir + 'test_total_article.txt'
        elif resource == 'internal':
            # Internal_class
            train_path = data_dir + 'train_internal_article_upsample.txt'
            dev_path = data_dir + 'dev_internal_article.txt'
            test_path = data_dir + 'test_internal_article.txt'
        elif resource == 'external':
            # External_class
            train_path = data_dir + 'train_external_article_upsample.txt'
            dev_path = data_dir + 'dev_external_article.txt'
            test_path = data_dir + 'test_external_article.txt'
    train_df = pd.read_csv(train_path).astype(str)
    dev_df = pd.read_csv(dev_path).astype(str)
    test_df = pd.read_csv(test_path).astype(str)
    # 拼接
    X_train = [' '.join(
        [words.strip() for words in list(jieba.lcut(sents)) if (words not in stopwords) and (str(words) != 'nan')]) for
        sents in train_df['text'].tolist()]
    y_train = train_df['label'].tolist()
    X_dev = [' '.join(
        [words.strip() for words in list(jieba.lcut(sents)) if (words not in stopwords) and (str(words) != 'nan')]) for
        sents in dev_df['text'].tolist()]
    y_dev = dev_df['label'].tolist()
    X_test = [' '.join(
        [words.strip() for words in list(jieba.lcut(sents)) if (words not in stopwords) and (str(words) != 'nan')]) for
        sents in test_df['text'].tolist()]
    y_test = test_df['label'].tolist()
    label_sorts = np.unique(y_train, return_inverse=True)[0]
    with open(label_output, 'w', encoding='utf-8') as f:
        for i, label in enumerate(label_sorts):
            print(i, label)
            f.write(str(i) + ',' + label+'\n')
        f.close()
    return (X_train, y_train, X_dev, y_dev, X_test, y_test)


def get_processing_data(path, split_symbol=',', ignore_row=1, train_ratio=0.8):
    """
    获取train.txt数据
    :param path:
    :return:
    """
    file_readlines = open(path, 'r', encoding='utf-8').readlines()
    data_dict = OrderedDict()
    for data in file_readlines[ignore_row:]:
        if '_both' in path:
            label, title, article = data.split(split_symbol)
            text = ','.join((title, article))
        else:
            label, text = data.split(split_symbol)
        if label not in data_dict:
            data_dict[label] = [text.strip()]
        else:
            data_dict[label].append(text.strip())
    # 切割训练集与测试集
    train_data_dict = {}
    test_data_dict = {}
    for label, text_list in data_dict.items():
        text_count = len(text_list)
        train_count = int(text_count * train_ratio)
        train_data_dict[label] = text_list[:train_count]
        test_data_dict[label] = text_list[train_count:]
    return train_data_dict, test_data_dict


def get_max_label(data_dict):
    # 统计数量
    max_label = 0
    for label, text_list in data_dict.items():
        print(label, len(text_list))
        if len(text_list) >= max_label:
            max_label = len(text_list)
    return max_label


# 上采样
def up_sample_data(input_path, train_output_path, dev_output_path=None, max_limit=None, split_symbol=','):
    """
    根据已有的数据进行上采样
    :param input_path:
    :param output_path:
    :param max_num:
    :param split_symbol:
    :return:
    """
    train_data_dict, test_data_dict = get_processing_data(input_path)
    # 统计数量
    max_label = get_max_label(train_data_dict) if max_limit is None else max_limit
    # exit()
    # 上采样
    up_sample_data = {}
    for label, text_list in train_data_dict.items():
        # 取长补短到设定个数
        up_sample_data[label] = int(max_label / len(text_list)) * text_list + text_list[:max_label - len(
            int(max_label / len(text_list)) * text_list)] if len(text_list) < max_label else text_list[:max_label]
    # 训练文件上采样后写入新文件
    with open(train_output_path, 'w', encoding='utf-8') as f:
        f.write('label' + split_symbol + 'text' + '\n')
        for label, text_list in up_sample_data.items():
            print('train:', label, len(text_list))
            for text in text_list:
                f.write(label + split_symbol + text + '\n')
        f.close()
    if dev_output_path is not None:
        # 测试文件直接写入文件
        print(dev_output_path)
        with open(dev_output_path, 'w', encoding='utf-8') as f:
            f.write('label' + split_symbol + 'text' + '\n')
            for label, text_list in test_data_dict.items():
                print('dev:', label, len(text_list))
                for text in text_list:
                    f.write(label + split_symbol + text + '\n')
            f.close()
    return up_sample_data


if __name__ == '__main__':
    # 处理文章长度，形成训练集
    # process_title_article(text_type='both', input_path='./document/智网txt - 内部/', ouput_file='./data/train_internal_both.txt')
    # 上采样+train_dev文件写入
    up_sample_data(max_limit=1000, input_path='./data/train_internal_both.txt',
                   train_output_path='./data/train_internal_both_upsample.txt', dev_output_path='./data/dev_internal_both.txt')
