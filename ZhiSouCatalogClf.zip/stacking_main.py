#!/usr/bin/env python
# encoding: utf-8
'''
@file: stacking_lr.py
@time: 2021/7/19 17:24
@author: SaKuraPan_
@desc:
'''
import pandas as pd
from numpy import array
from numpy import concatenate as np_concatenate
from utils import get_label, get_tags_dict
from dnn_main import IntentCLF
from tfidf_rfc import model_predict as rfc_predict
from tfidf_nb import model_predict as nb_predict
from tfidf_svm import model_predict as svm_predict
from stacking_lr import stackingLR_train, stackingLR_dev, stackingLR_predict
from multiprocessing import Pool
from configparser import ConfigParser

cfg = ConfigParser()
cfg.read('config.ini')
pool_num = cfg.getint('Param', 'pool')



def get_data(resource,data_path='./data/',file_type='both'):
    # 读取title/article的csv数据
    # train_df = pd.read_csv(data_path + 'train_article.txt').astype(str)
    # dev_df = pd.read_csv(data_path + 'dev_article.txt').astype(str)
    # test_df = pd.read_csv(data_path + 'test_article.txt').astype(str)
    # X_train, y_train = train_df['text'].tolist(), train_df['label'].tolist()
    # X_dev, y_dev = dev_df['text'].tolist(), dev_df['label'].tolist()
    # X_test, y_test = test_df['text'].tolist(), test_df['label'].tolist()
    # return (X_train,y_train,X_dev,y_dev,X_test,y_test)

    # 读取both的csv数据
    train_df = pd.read_csv(data_path + 'train_{0}_{1}_upsample.txt'.format(resource,file_type)).astype(str)
    dev_df = pd.read_csv(data_path + 'dev_{0}_{1}.txt'.format(resource,file_type)).astype(str)
    X_title, X_content, y_train = train_df['title'].tolist(), train_df['article'].tolist(), train_df['label'].tolist()
    dev_title, dev_content, y_dev = dev_df['title'].tolist(), dev_df['article'].tolist(), dev_df['label'].tolist()
    return (X_title, X_content, y_train, dev_title, dev_content, y_dev)


def bert_fc(sentence_list, model='bert_title'):
    # albert + fc
    cnn_model = IntentCLF('cpu', model)
    proba_bert = array([cnn_model.predict(sentence)[0] for sentence in sentence_list])
    print('bert shape:', proba_bert.shape)
    return proba_bert


def w2v_textcnn(sentence_list, model):
    # w2v_textcnn
    cnn_model = IntentCLF('cpu', model)
    proba_textcnn = array([cnn_model.predict(sentence)[0] for sentence in sentence_list])
    print(model, 'textcnn shape:', proba_textcnn.shape)
    return proba_textcnn


def tfidf_svm(sentence_list, resource):
    proba_svm = array(svm_predict(sentence_list, resource))
    print('svm_proba shape:', proba_svm.shape)
    # after_proba_svm = proba_svm / sum(proba_svm)
    return proba_svm


def tfidf_rfc(sentence):
    proba_rfc = array(rfc_predict(sentence))
    print('rfc_proba shape:', proba_rfc.shape)
    # after_proba_rfc = proba_rfc / sum(proba_rfc)
    return proba_rfc


def tfidf_nb(sentence_list):
    proba_nb = array(nb_predict(sentence_list))
    print('nb_proba shape:', proba_nb.shape)
    # after_proba_nb = proba_nb / sum(proba_nb)
    return proba_nb


def stacking_train(X_train, y_train, resource):
    X_title, X_article = X_train
    textcnn_title_result = w2v_textcnn(X_title, 'w2v_TextCNN_{0}_title'.format(resource))  # 默认title
    textcnn_article_result = w2v_textcnn(X_title, 'w2v_TextCNN_{0}_article'.format(resource))
    tfidf_svm_result = tfidf_svm(X_article, resource)
    # bert_title_result = bert_fc(X_title)
    # tfidf_nb_result = tfidf_nb(X_train)
    # tfidf_rfc_result = tfidf_rfc(X_train)
    x_train = np_concatenate((textcnn_title_result, textcnn_article_result, tfidf_svm_result), axis=1)
    print('x_train:', x_train)
    return stackingLR_train(x_train, y_train, resource)


def stacking_dev(X_dev, y_dev, resource):
    X_title, X_article = X_dev
    textcnn_title_result = w2v_textcnn(X_title, 'w2v_TextCNN_{0}_title'.format(resource))
    textcnn_article_result = w2v_textcnn(X_title, 'w2v_TextCNN_{0}_article'.format(resource))
    tfidf_svm_result = tfidf_svm(X_article, resource)
    # bert_title_result = bert_fc(X_title)
    # tfidf_nb_result = tfidf_nb(X_train)
    # tfidf_rfc_result = tfidf_rfc(X_train)
    x_dev = np_concatenate((textcnn_title_result, textcnn_article_result, tfidf_svm_result), axis=1)
    print('x_dev:', x_dev)
    return stackingLR_dev(x_dev, y_dev, resource)


def model_call(sentence_list, model_name, resource):
    if model_name == 'w2v_TextCNN_{0}_title'.format(resource):
        return w2v_textcnn(sentence_list, 'w2v_TextCNN_{0}_title'.format(resource))
    elif model_name == 'w2v_TextCNN_{0}_article'.format(resource):
        return w2v_textcnn(sentence_list, 'w2v_TextCNN_{0}_article'.format(resource))
    elif model_name == 'tfidf_svm':
        return tfidf_svm(sentence_list, resource)
    elif model_name == 'tfidf_nb':
        return tfidf_nb(sentence_list)
    elif model_name == 'tfidf_rfc':
        return tfidf_rfc(sentence_list)
    else:
        return


def stacking_predict(sentence_list, resource, top_k=None, pool=None):
    title, article = [title for title, article in sentence_list], [article for title, article in sentence_list]
    if pool is None:
        # get model output.
        textcnn_title_result = w2v_textcnn(title, 'w2v_TextCNN_{0}_title'.format(resource))
        textcnn_article_result = w2v_textcnn(article, 'w2v_TextCNN_{0}_article'.format(resource))
        tfidf_svm_result = tfidf_svm(article, resource)
        # bert_title_result = bert_fc(X_title)
        # tfidf_nb_result = tfidf_nb(title)
        # tfidf_rfc_result = tfidf_rfc(article)
    else:
        model_params = [(title, 'w2v_TextCNN_{0}_title'.format(resource), resource), (article, 'w2v_TextCNN_{0}_article'.format(resource), resource), (article, 'tfidf_svm', resource)]
        textcnn_title_result, textcnn_article_result, tfidf_svm_result = pool.starmap(model_call,
                                                                                      model_params)  # Proba_list
    output_list = [textcnn_title_result, textcnn_article_result, tfidf_svm_result]
    # for i in output_list: print('shape:', i.shape)
    x_test = np_concatenate(output_list, axis=1)
    # print(len(x_test), 'x_test:', x_test)
    result_list = stackingLR_predict(x_test, resource)
    # 输出导则结果
    top_k_idx_list = [result.argsort()[::-1][0:top_k] for result in result_list]  # 最大概率的前N个result
    label_proba = [{get_label(idx, class_path='./data/{0}_class.txt'.format(resource)): proba_list[idx] for idx in idx_list} for idx_list, proba_list in
                   zip(top_k_idx_list, result_list)]
    # print('predict result:', label_proba)
    return result_list, label_proba


if __name__ == '__main__':
    resource = 'total'   # total/internal/external
    # 获取训练数据
    # X_train,y_train,X_dev,y_dev,X_test,y_test = get_data()
    # X_title, X_article, y_train, dev_title, dev_article, y_dev = get_data(resource)
    # # 训练StackingLR模型
    # stacking_train(X_train=(X_title, X_article), y_train=y_train,resource=resource)
    # # 评估模型
    # stacking_dev(X_dev=(dev_title, dev_article), y_dev=y_dev, resource=resource)
    # exit()
    # 使用Multiprocessing创建多进程池
    pool = Pool(processes=pool_num)
    # 预测StackingLR模型
    result_list, label_proba = stacking_predict(sentence_list=[('国资委', '习近平总书记在国资委会议上提出'), ('火力发电', '最近新能源技术火力发电')], top_k=3,
                                                pool=pool, resource=resource)  # ['台风','发改委']
    print('predict result:', label_proba)
