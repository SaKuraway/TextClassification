# coding: UTF-8
import torch,os
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import configparser
# 读取配置文件
conf = configparser.ConfigParser()
conf.read("./models/model_config.ini")
# 读取参数
model_name = 'w2v_TextCNN'
model_output = 'w2v_TextCNN_external_title'
train_path = 'train_external_title_upsample.txt'
dev_path = 'dev_external_title.txt'
test_path = 'test_external_title.txt'
class_list = 'external_class.txt'
pad_size = 512
log_path = conf.get("Path", "log_path")
save_path = conf.get("Path", "save_path")
w2v_path = conf.get("Path", "w2v_path")
vocab_path = conf.get("Path", "vocab_path")
dropout = conf.getfloat("HyperParam", "dropout")
require_improvement = conf.getint("HyperParam", "require_improvement")
n_vocab = conf.getint("HyperParam", "n_vocab")
num_epochs = conf.getint("HyperParam", "num_epochs")
batch_size = conf.getint("HyperParam", "batch_size")
learning_rate = conf.getfloat("HyperParam", "learning_rate")
filter_sizes = eval(conf.get("HyperParam", "filter_sizes"))
num_filters = conf.getint("HyperParam", "num_filters")


class Config(object):

    """配置参数"""
    def __init__(self, dataset, device='cuda', embedding='embedding_SougouNews.npz'):
        self.model_name = model_output
        self.train_path = os.path.join(dataset, train_path)                                # 训练集
        self.dev_path = os.path.join(dataset, dev_path)                                    # 验证集
        self.test_path = os.path.join(dataset, test_path)                                  # 测试集
        self.class_path = os.path.join(dataset, class_list)                                  # 测试集
        self.class_list = [x.strip() for x in open(
            self.class_path, encoding='utf-8').readlines()]              # 类别名单
        self.vocab_path = vocab_path                                 # 词表
        self.save_path = save_path + self.model_name + '.ckpt'  # 模型训练结果
        self.log_path = log_path + self.model_name
        self.embedding_pretrained = torch.tensor(
            np.load(w2v_path, allow_pickle=True)["embeddings"].astype('float32')) \
            if embedding != 'random' else None                                       # 预训练词向量X
        self.device = torch.device(device)  # 'cuda' if torch.cuda.is_available() else 'cpu'  # 设备

        self.dropout = dropout                                              # 随机失活
        self.require_improvement = require_improvement                                 # 若超过1000batch效果还没提升，则提前结束训练
        self.num_classes = len(self.class_list)                         # 类别数
        self.n_vocab = n_vocab                                                # 词表大小，在运行时赋值
        self.num_epochs = num_epochs                                            # epoch数
        self.batch_size = batch_size                                           # mini-batch大小
        self.pad_size = pad_size                                              # 每句话处理成的长度(短填长切)
        self.learning_rate = learning_rate                                       # 学习率
        self.embed = self.embedding_pretrained.size(1)\
            if self.embedding_pretrained is not None else 300           # 字向量维度
        self.filter_sizes = filter_sizes                                   # 卷积核尺寸
        self.num_filters = num_filters                                          # 卷积核数量(channels数)


'''Convolutional Neural Networks for Sentence Classification'''


class Model(nn.Module):
    def __init__(self, config):
        super(Model, self).__init__()
        if config.embedding_pretrained is not None:
            self.embedding = nn.Embedding.from_pretrained(config.embedding_pretrained, freeze=False)
        else:
            self.embedding = nn.Embedding(config.n_vocab, config.embed, padding_idx=config.n_vocab - 1)
        self.convs = nn.ModuleList(
            [nn.Conv2d(1, config.num_filters, (k, config.embed)) for k in config.filter_sizes])
        self.dropout = nn.Dropout(config.dropout)
        self.fc = nn.Linear(config.num_filters * len(config.filter_sizes), config.num_classes)

    def conv_and_pool(self, x, conv):
        x = F.relu(conv(x)).squeeze(3)
        x = F.max_pool1d(x, x.size(2)).squeeze(2)
        return x

    def forward(self, x, predict=False):
        # print(x)
        if predict:
            out = self.embedding(x)
        else:
            out = self.embedding(x[0])
        out = out.unsqueeze(1)
        out = torch.cat([self.conv_and_pool(out, conv) for conv in self.convs], 1)
        out = self.dropout(out)
        out = self.fc(out)
        return out
    
