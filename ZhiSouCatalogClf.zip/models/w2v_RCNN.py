# coding: UTF-8
import torch,numpy as np
import torch.nn as nn
import torch.nn.functional as F
from pytorch_pretrained import BertModel, BertTokenizer
import configparser, os
# 读取配置文件
conf = configparser.ConfigParser()
conf.read("./models/model_config.ini")
# 读取参数
model_output = conf.get("Basic", "model_output")
train_path = conf.get("Path", "train_path")
log_path = conf.get("Path", "log_path")
save_path = conf.get("Path", "save_path")
dev_path = conf.get("Path", "dev_path")
test_path = conf.get("Path", "test_path")
class_list = conf.get("Path", "class_list")
bert_path = conf.get("Path", "bert_path")
vocab_path = conf.get("Path", "vocab_path")
dropout = conf.getfloat("HyperParam", "dropout")
require_improvement = conf.getint("HyperParam", "require_improvement")
n_vocab = conf.getint("HyperParam", "n_vocab")
w2v_path = conf.get("Path", "w2v_path")
num_epochs = conf.getint("HyperParam", "num_epochs")
batch_size = conf.getint("HyperParam", "batch_size")
pad_size = conf.getint("HyperParam", "pad_size")
learning_rate = conf.getfloat("HyperParam", "learning_rate")
filter_sizes = eval(conf.get("HyperParam", "filter_sizes"))
num_filters = conf.getint("HyperParam", "num_filters")
hidden_size = conf.getint("HyperParam", "hidden_size")
w2v_size = conf.getint("HyperParam", "w2v_size")
rnn_hidden = conf.getint("HyperParam", "rnn_hidden")
num_layers = conf.getint("HyperParam", "num_layers")

class Config(object):

    """配置参数"""
    def __init__(self, dataset, device='cuda', embedding='embedding_SougouNews.npz'):
        self.model_name = model_output
        self.train_path = os.path.join(dataset, train_path)                                 # 训练集
        self.dev_path = os.path.join(dataset, dev_path)                                    # 验证集
        self.test_path = os.path.join(dataset, test_path)                                  # 测试集
        self.class_list = [x.strip() for x in open(
            os.path.join(dataset, class_list)).readlines()]                                # 类别名单
        self.save_path = save_path + self.model_name + '.ckpt'  # 模型训练结果
        self.device = torch.device(device)  # 'cuda' if torch.cuda.is_available() else 'cpu'  # 设备

        self.embedding_pretrained = torch.tensor(
            np.load(w2v_path, allow_pickle=True)["embeddings"].astype('float32')) \
            if embedding != 'random' else None
        self.vocab_path = vocab_path
        self.require_improvement = require_improvement                                 # 若超过1000batch效果还没提升，则提前结束训练
        self.num_classes = len(self.class_list)                         # 类别数
        self.num_epochs = num_epochs                                             # epoch数
        self.batch_size = batch_size                                           # mini-batch大小
        self.pad_size = pad_size                                              # 每句话处理成的长度(短填长切)
        self.learning_rate = learning_rate                                       # 学习率
        self.bert_path = bert_path
        self.tokenizer = BertTokenizer.from_pretrained(self.bert_path)
        self.w2v_size = w2v_size
        self.hidden_size = hidden_size
        self.dropout = dropout
        self.rnn_hidden = rnn_hidden
        self.num_layers = num_layers


class Model(nn.Module):

    def __init__(self, config):
        super(Model, self).__init__()
        if config.embedding_pretrained is not None:
            self.embedding = nn.Embedding.from_pretrained(config.embedding_pretrained, freeze=False)
        else:
            self.embedding = nn.Embedding(config.n_vocab, config.embed, padding_idx=config.n_vocab - 1)

        self.lstm = nn.LSTM(config.w2v_size, config.rnn_hidden, config.num_layers,
                            bidirectional=True, batch_first=True, dropout=config.dropout)
        self.maxpool = nn.MaxPool1d(config.pad_size)
        self.fc = nn.Linear(config.rnn_hidden * 2 + config.w2v_size, config.num_classes)

    def forward(self, x, predict=False):
        # BERT
        # context = x[0]  # 输入的句子
        # mask = x[2]  # 对padding部分进行mask，和句子一个size，padding部分用0表示，如：[1, 1, 1, 1, 0, 0]
        # encoder_out, text_cls = self.bert(context, attention_mask=mask, output_all_encoded_layers=False)
        encoder_out = self.embedding(x[0])
        if predict:
            encoder_out = self.embedding(x)
        out, _ = self.lstm(encoder_out)
        out = torch.cat((encoder_out, out), 2)
        out = F.relu(out)
        out = out.permute(0, 2, 1)
        out = self.maxpool(out).squeeze()
        out = self.fc(out)
        return out
