# coding: UTF-8
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import configparser
# 读取配置文件
conf = configparser.ConfigParser()
conf.read("./models/model_config.ini")
# 读取参数
model_output = conf.get("Basic", "model_output")
train_path = conf.get("Path", "train_path")
log_path = conf.get("Path", "log_path")
save_path = conf.get("Path", "save_path")
dev_path = conf.get("Path", "dev_path")
test_path = conf.get("Path", "test_path")
class_list = conf.get("Path", "class_list")
w2v_path = conf.get("Path", "w2v_path")
vocab_path = conf.get("Path", "vocab_path")
dropout = conf.getfloat("HyperParam", "dropout")
require_improvement = conf.getint("HyperParam", "require_improvement")
n_vocab = conf.getint("HyperParam", "n_vocab")
num_epochs = conf.getint("HyperParam", "num_epochs")
batch_size = conf.getint("HyperParam", "batch_size")
pad_size = conf.getint("HyperParam", "pad_size")
learning_rate = conf.getfloat("HyperParam", "learning_rate")
filter_sizes = eval(conf.get("HyperParam", "filter_sizes"))
num_filters = conf.getint("HyperParam", "num_filters")

class Config(object):

    """配置参数"""
    def __init__(self, dataset, device='cuda', embedding='embedding_SougouNews.npz'):
        self.model_name = model_output
        self.train_path = os.path.join(dataset, train_path)                                # 训练集
        self.dev_path = os.path.join(dataset, dev_path)                                    # 验证集
        self.test_path = os.path.join(dataset, test_path)                                  # 测试集
        self.class_list = [x.strip() for x in open(
            os.path.join(dataset, class_list), encoding='utf-8').readlines()]              # 类别名单
        self.vocab_path = vocab_path                                # 词表
        self.save_path = save_path + self.model_name + '.ckpt'  # 模型训练结果
        self.log_path = log_path + self.model_name
        self.embedding_pretrained = torch.tensor(
            np.load(w2v_path, allow_pickle=True)["embeddings"].astype('float32')) \
            if embedding != 'random' else None                                       # 预训练词向量X
        self.device = torch.device(device)  # 'cuda' if torch.cuda.is_available() else 'cpu'  # 设备

        self.dropout = dropout                                              # 随机失活
        self.require_improvement = require_improvement                                 # 若超过1000batch效果还没提升，则提前结束训练
        self.num_classes = len(self.class_list)                         # 类别数
        self.n_vocab = n_vocab                                                # 词表大小，在运行时赋值
        self.num_epochs = num_epochs                                            # epoch数
        self.batch_size = batch_size                                           # mini-batch大小
        self.pad_size = pad_size                                              # 每句话处理成的长度(短填长切)
        self.learning_rate = learning_rate                                       # 学习率
        self.embed = self.embedding_pretrained.size(1) \
            if self.embedding_pretrained is not None else 300           # 字向量维度
        self.filter_sizes = filter_sizes                                   # 卷积核尺寸
        self.num_filters = num_filters


'''Deep Pyramid Convolutional Neural Networks for Text Categorization'''


class Model(nn.Module):
    def __init__(self, config):
        super(Model, self).__init__()
        if config.embedding_pretrained is not None:
            self.embedding = nn.Embedding.from_pretrained(config.embedding_pretrained, freeze=False)
        else:
            self.embedding = nn.Embedding(config.n_vocab, config.embed, padding_idx=config.n_vocab - 1)
        self.conv_region = nn.Conv2d(1, config.num_filters, (3, config.embed), stride=1)
        self.conv = nn.Conv2d(config.num_filters, config.num_filters, (3, 1), stride=1)
        self.max_pool = nn.MaxPool2d(kernel_size=(3, 1), stride=2)
        self.padding1 = nn.ZeroPad2d((0, 0, 1, 1))  # top bottom
        self.padding2 = nn.ZeroPad2d((0, 0, 0, 1))  # bottom
        self.relu = nn.ReLU()
        self.fc = nn.Linear(config.num_filters, config.num_classes)

    def forward(self, x, predict=False):
        x = self.embedding(x[0])
        if predict:
            x = self.embedding(x)
        x = x.unsqueeze(1)  # [batch_size, 250, seq_len, 1]
        x = self.conv_region(x)  # [batch_size, 250, seq_len-3+1, 1]

        x = self.padding1(x)  # [batch_size, 250, seq_len, 1]
        x = self.relu(x)
        x = self.conv(x)  # [batch_size, 250, seq_len-3+1, 1]
        x = self.padding1(x)  # [batch_size, 250, seq_len, 1]
        x = self.relu(x)
        x = self.conv(x)  # [batch_size, 250, seq_len-3+1, 1]
        while x.size()[2] > 2:
            x = self._block(x)
        x = x.squeeze()  # [batch_size, num_filters(250)]
        x = self.fc(x)
        return x

    def _block(self, x):
        x = self.padding2(x)
        px = self.max_pool(x)

        x = self.padding1(px)
        x = F.relu(x)
        x = self.conv(x)

        x = self.padding1(x)
        x = F.relu(x)
        x = self.conv(x)

        # Short Cut
        x = x + px
        return x
