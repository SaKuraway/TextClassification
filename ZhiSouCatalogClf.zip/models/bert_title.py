# coding: UTF-8
import torch,configparser,os
import torch.nn as nn
# from pytorch_pretrained_bert import BertModel, BertTokenizer
from pytorch_pretrained import BertModel, BertTokenizer
# 读取配置文件
conf = configparser.ConfigParser()
conf.read("./models/model_config.ini")
# 读取参数
model_name = 'bert'
model_output = 'bert_title'
train_path = 'train_title_upsample.txt'
dev_path = 'dev_title.txt'
test_path = 'test_title.txt'
pad_size = 50
log_path = conf.get("Path", "log_path")
save_path = conf.get("Path", "save_path")
class_list = conf.get("Path", "class_list")
vocab_path = conf.get("Path", "vocab_path")
bert_path = conf.get("Path", "bert_path")
dropout = conf.getfloat("HyperParam", "dropout")
require_improvement = conf.getint("HyperParam", "require_improvement")
n_vocab = conf.getint("HyperParam", "n_vocab")
num_epochs = conf.getint("HyperParam", "num_epochs")
batch_size = conf.getint("HyperParam", "batch_size")
learning_rate = conf.getfloat("HyperParam", "learning_rate")
filter_sizes = eval(conf.get("HyperParam", "filter_sizes"))
num_filters = conf.getint("HyperParam", "num_filters")
hidden_size = conf.getint("HyperParam", "hidden_size")


class Config(object):
    """配置参数"""
    def __init__(self, dataset, device='cuda'):
        self.model_name = model_output
        self.train_path = os.path.join(dataset, train_path)  # 训练集
        self.dev_path = os.path.join(dataset, dev_path)  # 验证集
        self.test_path = os.path.join(dataset, test_path)  # 测试集
        self.class_list = [x.strip() for x in open(
            os.path.join(dataset, class_list)).readlines()]  # 类别名单
        self.save_path = save_path + self.model_name + '.ckpt'  # 模型训练结果
        self.device = torch.device(device)  # 'cuda' if torch.cuda.is_available() else 'cpu'  # 设备

        self.require_improvement = require_improvement  # 若超过1000batch效果还没提升，则提前结束训练
        self.num_classes = len(self.class_list)  # 类别数
        self.num_epochs = num_epochs  # epoch数
        self.batch_size = batch_size  # mini-batch大小
        self.pad_size = pad_size  # 每句话处理成的长度(短填长切)
        self.learning_rate = learning_rate  # 学习率
        self.bert_path = bert_path
        self.tokenizer = BertTokenizer.from_pretrained(self.bert_path)
        self.hidden_size = 768


class Model(nn.Module):

    def __init__(self, config):
        super(Model, self).__init__()
        self.bert = BertModel.from_pretrained(config.bert_path)
        for param in self.bert.parameters():
            param.requires_grad = True
        self.fc = nn.Linear(config.hidden_size, config.num_classes)

    def forward(self, x, predict=False):
        if predict:
            encoded_layer, pooled = self.bert(x)
            # pooled = encoded_layer[-1]
            # import numpy as np
            # print('encoded_layer:', np.array(encoded_layer).shape)
            # print('_:', np.array(_).shape)
            # print('pooled:', np.array(pooled).shape)
        else:
            context = x[0]  # 输入的句子
            mask = x[2]  # 对padding部分进行mask，和句子一个size，padding部分用0表示，如：[1, 1, 1, 1, 0, 0]
            _, pooled = self.bert(context, attention_mask=mask, output_all_encoded_layers=False)
        out = self.fc(pooled)

        return out
