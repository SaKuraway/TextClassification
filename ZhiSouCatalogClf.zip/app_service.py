# coding=utf-8
from stacking_main import stacking_predict
from flask import Flask, render_template, request, jsonify
import configparser
from time import time
from multiprocessing import Pool
from utils import get_tags_dict
from logger import get_logger

# 读取配置文件
conf = configparser.ConfigParser()
conf.read("config.ini")
is_debug = conf.get("Basic", "debug")
log_path = conf.get('Basic', 'log_path')
# 日志控制器
logger = get_logger('catalog_clf', log_path, 'CataLogs.log')
# 使用Multiprocessing创建多进程池
pool_num = conf.getint('Param', 'pool')
pool = Pool(processes=pool_num)
# 获取三级目录tags
tags_dict = get_tags_dict()

# 初始化函数
app = Flask(__name__, static_url_path="/static")
app.config['JSON_AS_ASCII'] = False
if is_debug == 'True':
    host = conf.get("Server_dev", "host")
    port = conf.get("Server_dev", "port")
else:
    host = conf.get("Server_pro", "host")
    port = conf.get("Server_pro", "port")
print(is_debug, host, port)


def loggings(*args, type='INFO'):
    """
    将printf出来的数据保存到LOG文件。
    :param args:
    :return:
    """
    args = ' '.join([str(arg) for arg in args])
    if type == 'DEBUG':
        logger.debug(args)
    elif type == 'INFO':
        logger.info(args)
    elif type == 'WARNING':
        logger.warning(args)
    elif type == 'ERROR':
        logger.error(args)
    elif type == 'CRITICAL':
        logger.critical(args)


def get_classify_dict(class_path):
    """
    :param search_title:  分类label对应classification
    :return:  label_dict
    """
    return {i: class_.split(' ')[-1].strip() for i, class_ in
            enumerate(open(class_path, 'r', encoding='utf-8').readlines())}


@app.route('/AIwriting/catalog/clf', methods=['POST'])
def Gddw_intent(code=0, message=None, result=None):
    """
    前端调用接口。
    路径：/gddw/intent
    请求方式：POST
    请求参数：text,model
    :return: Best similar intent prediction and its probability.
    """
    # 判断从请求中获取参数信息是否为空
    try:
        t0 = time()
        loggings('='*100+'\n', request.form.to_dict())
        mode = request.form['mode']
        top_k = int(request.form['top_k']) if 'top_k' in request.form.keys() else 3
        resource = 'internal' if int(mode) == 1 else 'external' if int(mode) == 2 else 'total' if int(
            mode) == 0 else 'None'
        title = request.form['title']
        article = request.form['textcontent']
        # Stacking CLF
        prediction, label_proba = stacking_predict(sentence_list=[(title, article)], resource=resource, top_k=top_k,
                                                   pool=pool)
        print('predict result:', label_proba)
        result = [{'tag1': tags_dict[tag][0], 'tag2': tags_dict[tag][1], 'tag3': tags_dict[tag][2], 'proba': proba} for
                  tag, proba in label_proba[0].items()]
        code = 1
        message = 'Successed With mode {0}'.format(mode)
    except Exception as e:
        # exception
        code = 0
        message = 'Failed With mode {0}.{1}'.format(mode, str(e))
        print(message)
    finally:
        # return final result.
        loggings({'code': code, 'message': message, 'result': result})
        return jsonify({'code': code, 'message': message, 'result': result ,'time_used':time()-t0})


@app.route("/")
def index():
    return render_template("/index.html")


def runmain():
    # 启动app服务
    app.run(host=host, port=int(port))


# 启动APP
if __name__ == "__main__":
    runmain()
