## 此处存放bert预训练模型：  
pytorch_model.bin  
bert_config.json  
vocab.txt  

## 下载地址：  
https://s3.amazonaws.com/models.huggingface.co/bert/bert-base-chinese.tar.gz  