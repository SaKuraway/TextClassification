# Bert-Chinese-Text-Classification-Pytorch
[![LICENSE](https://img.shields.io/badge/license-Anti%20996-blue.svg)](https://github.com/996icu/996.ICU/blob/master/LICENSE)

 ZhiSouCatalogClf
├── app_service.py: 智能写作目录分类的flask服务，提供接口，接口参数有model和text（详见接口文档）。将预测的结果对应为中文label及概率proba返回给用户。
├── article_eval_result.txt: 文章目录分类各模型的准确率result
├── bert_pretrain: BERT与训练模型的文件
├── config.ini: 配置文件
├── data: 训练、验证及预测的数据
├── data_process.py: 数据预处理代码
├── dnn_main.py: 深度学习dnn（Bert+Fc、w2v+TextCnn等代码）的训练、验证及预测的调用代码
├── intent_fasttext.py: 使用fasttext的数据处理、训练及预测调用代码(本次上线没用到)
├── lib: 相关资源库，如停用词典、分词词典等
├── logger.py: 日志记录代码
├── logs: 日志目录
├── model_output: 模型输出目录文件夹（title是标题相关的训练模型、article是文章相关的训练模型、both是标题+正文两者结合的训练模型、internal是内部数据的训练模型、external是外部数据的训练模型、total是内部+外部两者结合的训练模型）
├── models: 相关深度学习的torch代码
├── pytorch_pretrained: pytorch的预训练代码
├── README.md: 本说明文档
├── run_main.py: 启动app_server的代码
├── run_main.sh: 启动run_main的bash代码
├── stacking_lr.py: 使用LR作为集成模型stacking的次级学习器，提供LR的训练、验证及预测的调用代码
├── stacking_main.py: 使用标题textcnn+正文svm+正文textcnn作为初级学习器，其softmax预测结果输入到次级学习器LR中，提供stacking的训练、验证及预测的调用代码
├── test.py: 部署后的http调用测试代码
├── tfidf_nb.py: 使用tfidf作为特征，朴素贝叶斯NaiveBayes作为学习器，提供其训练、验证及预测的调用代码(本次上线没用到)
├── tfidf_rfc.py: 使用tfidf作为特征，随机森林RandomForest作为学习器，提供其训练、验证及预测的调用代码
├── tfidf_svm.py: 使用tfidf作为特征，支持向量机SVM作为学习器，提供其训练、验证及预测的调用代码
├── train_eval_predict.py: 深度学习的训练、验证及预测的实际执行调用代码
├── utils.py: Bert相关的数据预处理代码
├── w2v_utils.py: w2v相关的数据预处理代码
├── version.txt: 版本说明
