# coding: UTF-8
import os
import time
import torch
import numpy as np
from train_eval_predict import train, evaluate, predict, init_network
from importlib import import_module
import argparse,configparser
# 读取配置文件
conf = configparser.ConfigParser()
conf.read("./models/model_config.ini")
model_name = conf.get("Basic", "model_name")
if 'bert' in model_name:
    from utils import build_dataset, build_iterator, get_time_dif, get_label
elif 'w2v' in model_name:
    from w2v_utils import build_dataset, build_iterator, get_time_dif, get_label

# from bert_RNN import Model

# parser = argparse.ArgumentParser(description='Chinese Text Classification')
# parser.add_argument('--model', type=str, required=True, default='bert_RNN' ,help='choose a model: Bert, ERNIE')
# args = parser.parse_args()
class IntentCLF():
    def __init__(self, device, model=model_name):
        # model_name = #'w2v_DPCNN' # args.model
        dataset = 'data'  # 数据集
        x = import_module('models.' + model)
        # 读取参数
        self.device = device
        self.config = x.Config(dataset, self.device)
        np.random.seed(1)
        torch.manual_seed(1)
        torch.cuda.manual_seed_all(1)
        torch.backends.cudnn.deterministic = True  # 保证每次结果一样
        # 装载model
        self.model = x.Model(self.config).to(self.config.device)
        # 加载已有模型
        try:
            self.model.load_state_dict(torch.load(self.config.save_path, map_location=self.device))
            print('加载已有模型:', self.config.save_path)
        except Exception as e:
            print(self.config.save_path, '初始模型加载失败', e)

    def train_dev(self):
        start_time = time.time()
        print("Loading data...")
        train_data, dev_data, test_data = build_dataset(self.config)
        print('train_data:', train_data[:2])
        print('dev_data:', dev_data[:2])
        print('test_data:', test_data[:2])
        train_iter = build_iterator(train_data, self.config)
        dev_iter = build_iterator(dev_data, self.config)
        test_iter = build_iterator(test_data, self.config)
        time_dif = get_time_dif(start_time)
        print("Time usage:", time_dif)
        train(self.config, self.model, train_iter, dev_iter, test_iter)

    def test(self):
        # test
        print("Loading data...")
        train_data, dev_data, test_data = build_dataset(self.config)
        print('test_data:', test_data[:2])
        test_iter = build_iterator(test_data, self.config)
        self.model.load_state_dict(torch.load(self.config.save_path))
        self.model.eval()
        start_time = time.time()
        test_acc, test_loss, test_report, test_confusion = evaluate(self.config, self.model, test_iter, test=True)
        msg = 'Test Loss: {0:>5.2},  Test Acc: {1:>6.2%}'
        print(msg.format(test_loss, test_acc))
        print("Precision, Recall and F1-Score...")
        print(test_report)
        print("Confusion Matrix...")
        print(test_confusion)
        time_dif = get_time_dif(start_time)
        print("Time usage:", time_dif)

    def predict(self, text):
        # 加载参数
        # self.model.load_state_dict(torch.load(self.config.save_path, map_location=self.device))
        self.model.eval()
        # 预测结果
        result = predict(self.config, self.model, text, device=self.device)
        # 打印结果
        # for y in result:
        #     predict_proba = {get_label(i, self.config.class_path): label_prob_list.item() for i, label_prob_list in enumerate(list(y))}
        #     print(sorted(predict_proba.items(), key=lambda x: x[1], reverse=True))
        return result

if __name__ == '__main__':
    intent_clf = IntentCLF('cuda')
    # Run_train_dev
    intent_clf.train_dev()
    # Run test
    # intent_clf.test()
    while True:
        text = input('请输入需要预测意图的句子:')
        result = intent_clf.predict(text)
        for y in result:
            predict_proba = {get_label(i,intent_clf.config.class_path): label_prob_list.item() for i, label_prob_list in enumerate(list(y))}
            print(sorted(predict_proba.items(), key=lambda x: x[1], reverse=True))

